

class Breakpoints {
  static const sm = 640;
  static const md = 768;
}

